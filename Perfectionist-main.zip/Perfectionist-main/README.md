Here we initially upload the copies of our files just to test that we can push files from our local machines 
and if something were to go wrong, the good thing is that the copy-version was affected.
